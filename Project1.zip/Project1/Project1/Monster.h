#pragma once
#include "Enemy.h"
class Monster : public Enemy
{
public:
	bool left;
	//attributes
	
public:
	Monster();
	void move();
	void fire(float);
	~Monster(){}
};
