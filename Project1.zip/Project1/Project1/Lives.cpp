#ifndef LIVES_H
#define LIVES_H

#include "Lives.h"

Lives::Lives()
{
	tex.loadFromFile("img/live.png");
	sprite.setTexture(tex);
	
	x=rand()% 620 + 10;
	y=0;
	
	sprite.setPosition(x,y);
	sprite.setScale(1,1);
	active = timed = false;
	
	type = "lives";
}

void Lives::fall(float time)
{
	y+=0.1;
	sprite.setPosition(x,y);
	
}
#endif
