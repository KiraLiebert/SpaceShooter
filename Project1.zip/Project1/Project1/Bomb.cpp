#ifndef BOMB_H
#define BOMB_H

#include "Bomb.h"

Bomb::Bomb(float a, float b, std::string t)
{
	type = t;
	
	std::string img;
	
	int delay = 0;
	if (type == "alpha")
		img = "img/bomb1.png";
	else if (type == "beta")
		img = "img/bomb2.png";
	else if (type == "gamma")
		img = "img/bomb3.png";
	else if ( type == "monster")
		img = "img/laser.png";
	else
		img = "img/bomb3.png";
	
	tex.loadFromFile(img);
	sprite.setTexture(tex);
	
	r = rand() % 10;
	
	x=a+30;
	y=b+70;
	
	sprite.setPosition(x,y);
	xx = a;
	yy = b;
}

void Bomb::fire(float time)
{
	
	int delay = 3;
	if (type == "alpha")
		delay = 5;
	else if (type == "beta")
		delay = 3;
	else if (type == "gamma")
		delay = 2;
	
	
	int t = time + r;
	t = t % delay;
	
	if (!p)
	{
		if ((t==0)&&(!bombDrop))
		{
			bombDrop = true;
		}
		
		if((bombDrop)&&(timed))
		{
			y = yy+70;
			x = xx+30;
			timed = false;
		}
	}
	
	y+=0.25;
	sprite.setPosition(x,y);
	
	if (t!=0)
	{
		timed = true;
		bombDrop = false;
	}
}

#endif
