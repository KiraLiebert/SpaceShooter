#pragma once
#include "Invader.h"

class Alpha : public Invader
{

public:
	//attributes
	bool bombDrop,timed;
	int r;
	
public:
	Alpha();
	void move();
	void fire(float);
	~Alpha(){}
};
