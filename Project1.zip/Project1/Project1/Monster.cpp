
#ifndef MONSTER_H
#define MONSTER_H

#include "Monster.h"

Monster::Monster()
{
	tex.loadFromFile("img/monster.png");
	sprite.setTexture(tex);
	
	x=100;
	y=50;
	
	sprite.setPosition(x,y);
	sprite.setScale(1,1);
	
	bomb = new Bomb(x+65,y-20,"monster");
	bomb->sprite.setScale(1,20);
	left = false;
	type = "monster";
}

void Monster::move()
{
	float m;
	
	if (left)
	{
		x-=0.1;
		m = -0.1;
	}
	else
	{
		x+=0.1;
		m = 0.1;
	}
	
	sprite.move(m,0);
	
	if (x<-110)
	{
		x = -109;
		left = false;
	}
	else if (x>550)
	{
		x = 549;
		left = true;
	}
	
	sprite.setPosition(x,y);
	
}

void Monster::fire(float time)
{
	int t = time;
	t = t % 5;
	
	bomb->x = x + 95;
	bomb->y = y + 50;
	bomb->sprite.setPosition (bomb->x, bomb->y);
	
	if (t<2)
	{
		bomb->sprite.setPosition(-100,-100);
		bomb->x = -100;
		bomb->y = -100;
	}
}

#endif
