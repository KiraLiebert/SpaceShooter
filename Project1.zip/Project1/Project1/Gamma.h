#pragma once
#include "Invader.h"

class Gamma : public Invader
{

public:
	//attributes
	bool bombDrop,timed;
	int r;
	
public:
	Gamma();
	void move();
	void fire(float);
	~Gamma(){}
};
