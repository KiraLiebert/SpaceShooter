#ifndef DANGER_H
#define DANGER_H

#include "Danger.h"

Danger::Danger()
{
	tex.loadFromFile("img/danger.png");
	sprite.setTexture(tex);
	
	x=rand()% 620 + 10;
	y=0;
	
	sprite.setPosition(x,y);
	sprite.setScale(1,1);
	active = timed = false;
	
	type = "danger";
}

void Danger::fall(float time)
{
	
	y+=0.1;
	sprite.setPosition(x,y);
}
#endif
