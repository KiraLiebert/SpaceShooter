#pragma once
#include "HighScore.h"
#include<SFML/Graphics.hpp>
using namespace std;
using namespace sf;
class Menu
{

public:
	Sprite background;
	Texture bg_texture;
	Sprite sideBackground;
	Texture side_tex;
	Sprite menu;
	Texture t;
	Sprite instruct;
	Texture s;
	Sprite highScore;
	Texture hh;
	Sprite name;
	Texture n;
	
	HighScore h;
	
	string* scores;
	string* names;
	sf::Font font;
	
	bool selected, game;
	int position;
	string username;
	
public:

	Menu();
	int display_menu(sf::RenderWindow &window, Event &e);
};
