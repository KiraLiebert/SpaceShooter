#pragma once
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <time.h>
#include <iostream>
using namespace std;

#include "Player.h"
//#include "Enemy.h"
//#include "Alpha.h"
//#include "Beta.h"
//#include "Gamma.h"
//#include "Monster.h"
//#include "Dragon.h"
#include "AddOn.h"
#include "Lives.h"
#include "Menu.h"
#include "Shape.h"
#include "PowerUp.h"

const char title[] = "Space Shooter";
using namespace sf;
using namespace std;

class Game
{

public:
	Sprite background;
	Texture bg_texture;
	Sprite sideBackground;
	Texture side_tex;
	
	Sprite sideMenu;
	Texture sidemenu_tex;
	
	Sprite gameOver;
	Texture g;
	
	Sprite obj1;
	Texture obj1tex;
	Sprite obj2;
	Texture obj2tex;
	
	Menu m;
	Shapes s;
	sf::Font font;
	sf::Music gameMusic,menuMusic;
	
	Player* p;
	Enemy** enemy;
	Bomb** bomb;
	Enemy* enemy2;
	AddOn* addOns;
	int numberOfEnemies;
	
	float obj1X;
	float obj2X;
	
	bool animation;
	bool animationStart;
	bool reverse;
	
	float timer;
	float fireTimer;
	bool fireStart;
	
	bool powerupStart;
	float powerupTimer;
	
	bool right, left , up , down;
	
	bool nextLevel;
	bool end;
	int level;
	int phase;
	int score;
	
	bool Invaderpause;
	bool pause;
	
	string username;
	
	bool nextLevelPause;
	int nextLevelTimer;
	
public:
	
	Game();
	void start_game(); // Start of the game
	void showMenu(int); //Show menu at the start of the game.
	void initializeVariables(); // Initializing the variables with default values.
	void readGame(); // Reading all the variables of the game stored in the file.
	void writeGame(); // Storing all the variables of the game in a file.
	void chooseLevel(); //Choose Level according to the enemies destroyed.
	void checkAnimation(); //Check for the animation in the start of a level.
	void showAnimation(); //Show animation if level is increased.
	void checkAddOns(); //Check if a new addOn is selected.
	void destroyPlayer(Enemy*&); //If player is hit by enemy it is destroyed.
	void destroyPlayer(Bomb *&); //If player is hit by bomb it is destroyed.
	void destroyEnemy(Enemy*&); ////If enemy is hit by player bullet it is destroyed.
	void checkPlayerCordinates(); //Checking player cordinates.
	void drawFonts(sf::RenderWindow &window); //Drawing the font sprites on the screen.
	void drawObjects(sf::RenderWindow &window); //Drawing all other sprites on the screen.
	void callFunctions(); //Calling all the important functions during the game.
};
