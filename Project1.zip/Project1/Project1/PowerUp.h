#pragma once
#include "AddOn.h"
class PowerUp : public AddOn
{
public:
	//attributes
	bool active,timed;
	
public:
	PowerUp();
	void fall(float time);
	~PowerUp(){}
};
