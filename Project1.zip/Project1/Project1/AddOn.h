#pragma once
#include <SFML/Graphics.hpp>
#include<string.h>
using namespace sf;

class AddOn
{
public:
	Texture tex;
	Sprite sprite;
	float x,y;
	std::string type;

public:
	AddOn();
	virtual void fall(float) = 0;
	virtual ~AddOn();
};