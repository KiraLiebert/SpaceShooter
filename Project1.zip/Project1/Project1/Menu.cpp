#include "Menu.h"
#ifndef MENU_H
#define MENU_H
#include<SFML/Graphics.hpp>
#include<SFML/Window/Keyboard.hpp>
using namespace std;
using namespace sf;

Menu::Menu()
{
	bg_texture.loadFromFile("img/background.jpg");
	background.setTexture(bg_texture);
	side_tex.loadFromFile("img/side.png");
	sideBackground.setTexture(side_tex);
	sideBackground.move(640,0);
	t.loadFromFile("img/menu.png");
	menu.setTexture(t);
	n.loadFromFile("img/takename.png");
	name.setTexture(n);
	hh.loadFromFile("img/highscore.png");
	highScore.setTexture(hh);
	s.loadFromFile("img/instructions.png");
	instruct.setTexture(s);
	font.loadFromFile("arial.ttf");
	
	selected = game = false;
	position = 0;
	username = "";
}

int Menu::display_menu(sf::RenderWindow &window, Event &e)
{
	
	sf::Text nameText;
	nameText.setFont(font);
	nameText.setCharacterSize(70);
	nameText.setFillColor(sf::Color::White);
	nameText.setPosition(170.f, 300.f);
	
	while(!game)
	{
		while (window.pollEvent(e))
		{
			if (e.type == Event::Closed)
				return 0;
			else if (selected && position == 1)
			{
				if (e.type == sf::Event::TextEntered)
				{
					if (e.text.unicode < 128)
					{
						if (e.text.unicode == 13 && !username.empty())
							return 1;
						else if (e.text.unicode == '\b' && !username.empty())
							username.pop_back();
						else if (e.text.unicode != '\b' && e.text.unicode != 13)
							username += static_cast<char>(e.text.unicode);
					}
				}
				nameText.setString(username);
			}
		}
		
		if (e.type == Event::KeyReleased)
		{
			
			if (!selected)
			{
				if (e.key.code == Keyboard::N)
				{
					username = "";
					position = 1;
					selected = true;
				}
				else if (e.key.code == Keyboard::R)
				{
					if (username != "")
						return 2;
				}
				else if (e.key.code == Keyboard::I)
				{
					position = 3;
					selected = true;
				}
				else if (e.key.code == Keyboard::B)
				{
					position = 4;
					selected = true;
				}
				else if (e.key.code == Keyboard::H)
				{
					position = 5;
					selected = true;
				}
				else if (e.key.code == Keyboard::Escape)
				{
					return 0;
				}
			}
			
			if (position == 5)
			{
				h.Sort();
				names = h.getNames();
				scores = h.getScores();
			}
			else if (position == 4)
			{
				bg_texture.loadFromFile("img/chooseBackground.jpg");
				background.setTexture(bg_texture);
			}
		}
		
		if (selected)
		{
			if (e.type == Event::KeyReleased)
			{
				
				if (position == 4)
				{
					if (e.key.code == Keyboard::Num1)
					{
						bg_texture.loadFromFile("img/background.jpg");
						background.setTexture(bg_texture);
						selected = false;
						position = 0;
					}
					else if (e.key.code == Keyboard::Num2)
					{
						bg_texture.loadFromFile("img/background1.jpg");
						background.setTexture(bg_texture);
						selected = false;
						position = 0;
					}
					else if (e.key.code == Keyboard::Num3)
					{
						bg_texture.loadFromFile("img/background2.jpg");
						background.setTexture(bg_texture);
						selected = false;
						position = 0;
					}
					else if (e.key.code == Keyboard::Num4)
					{
						bg_texture.loadFromFile("img/background3.jpg");
						background.setTexture(bg_texture);
						selected = false;
						position = 0;
					}
					else if (e.key.code == Keyboard::Num5)
					{
						bg_texture.loadFromFile("img/background4.jpg");
						background.setTexture(bg_texture);
						selected = false;
						position = 0;
					}
					else if (e.key.code == Keyboard::Num6)
					{
						bg_texture.loadFromFile("img/background5.jpg");
						background.setTexture(bg_texture);
						selected = false;
						position = 0;
					}
				}
				else if (e.key.code == Keyboard::M && position!= 1)
				{
					selected = false;
					position = 0;
				}
				
			}
		}
		std::vector<sf::Text> Names(h.Count());
		std::vector<sf::Text> Scores(h.Count());
	/*	sf::Text Names[h.Count()];
		sf::Text Scores[h.Count()];*/
		
		
		if (selected && position == 5)
		{
			///////////////////Text Outputs //////////////////
			
			// Setting common elements like font, fontsize, color, style once.
			Names[0].setFont(font);
			Names[0].setFillColor(sf::Color::Red);
			Names[0].setStyle(sf::Text::Bold );
			Names[0].setCharacterSize(30);
			
			//Passing the common elements to other text variables.
			for (int i = 0; i < h.Count(); i++)
			{
				Names[i] = Scores[i] = Names[0];
			}
			
			for (int i = 0; i < h.Count(); i++)
			{
				string n = to_string(i+1) + " " + names[i];
				Names[i].setString(n);
				Scores[i].setString(scores[i]);
			}
			//level.setString(std::to_string(current_level));
			
			//Setting their positions.
			for (int i = 0; i < h.Count(); i++)
			{
				Scores[i].move(480, 40*(i+1)+100);
				Names[i].setPosition(90, 40*(i+1)+100);
			}
			///////////////Text Output End Here///////////////////
		}
		
		
		window.clear(Color::Black);
		window.draw(background);
		window.draw(sideBackground);
		if (!selected)
		{
			window.draw(menu);
		}
		
		if (selected && position == 1)
		{
			window.draw(name);
			window.draw(nameText);
		}
		
		if (selected && position == 3)
		{
			window.draw(instruct);
		}
		
		if (selected && position == 5)
		{
			window.draw(highScore);
			for (int i = 0; i < h.Count(); i++)
			{
				window.draw(Scores[i]);
				window.draw(Names[i]);
			}
		}
		window.display();
	}
	return -1;
}

#endif
