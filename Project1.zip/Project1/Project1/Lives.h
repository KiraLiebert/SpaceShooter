#pragma once
#include "AddOn.h"
class Lives : public AddOn
{
public:
	//attributes
	bool active,timed;
	
public:
	Lives();
	void fall(float time);
	~Lives(){}
};
