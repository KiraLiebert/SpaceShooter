#pragma once
#include "Invader.h"

class Beta : public Invader
{

public:
	//attributes
	bool bombDrop,timed;
	int r;
	
	
public:
	Beta();
	void move();
	void fire(float);
	~Beta(){}
};
