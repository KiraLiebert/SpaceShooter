#ifndef SHAPE_H
#define SHAPE_H
#include "Shape.h"

void Shapes::makeRectangle(int& numberOfEnemies, Enemy** &enemy, Bomb** &bomb)
{
	
	numberOfEnemies = 12;
	
	for (int i = 0; i < 12; i++)
	{
		int mod = rand() % 3;
		if (mod==0)
		enemy[i] = new Alpha;
		else if (mod==1)
		enemy[i] = new Beta;
		else
		enemy[i] = new Gamma;
	}
	
	
	for (int i = 0; i < 5; i++)
	{
		enemy[i]->x += (110*i);
		enemy[i]->sprite.setPosition(enemy[i]->x, enemy[i]->y);
	}
	
	enemy[5]->x += (110*4);
	enemy[5]->y += (110);
	enemy[5]->sprite.setPosition(enemy[5]->x, enemy[5]->y);
	
	enemy[6]->y += (110);
	enemy[6]->sprite.setPosition(enemy[6]->x, enemy[6]->y);
		
	for (int i = 7; i < 12; i++)
	{
		enemy[i]->x += (110*(i-7));
		enemy[i]->y += (220);
		enemy[i]->sprite.setPosition(enemy[i]->x, enemy[i]->y);
	}
	
	for (int i = 0; i < numberOfEnemies; i++)
	{
		string t;
		if (enemy[i]->type == "alpha")
			t = "alpha";
		else if (enemy[i]->type == "beta")
			t = "beta";
		else if (enemy[i]->type == "gamma")
			t = "gamma";
		
		delete bomb[i];
		bomb[i] = new Bomb(enemy[i]->x, enemy[i]->y, t);
		enemy[i]->bomb = bomb[i];
	}
}

void Shapes::makeTriangle(int& numberOfEnemies, Enemy** &enemy, Bomb** &bomb)
{
	
	numberOfEnemies = 13;
	
	for (int i = 0; i < 13; i++)
	{
		int mod = rand() % 3;
		if (mod==0)
		enemy[i] = new Alpha;
		else if (mod==1)
		enemy[i] = new Beta;
		else
		enemy[i] = new Gamma;
	}
	
	for (int i = 0; i < 6; i++)
	{
		enemy[i]->x += (100*i);
		enemy[i]->sprite.setPosition(enemy[i]->x, enemy[i]->y);
	}

	for (int i = 6; i < 9; i++)
	{
		enemy[i]->x += (100*(i-6));
		enemy[i]->y += (100*(i-5));
		enemy[i]->sprite.setPosition(enemy[i]->x, enemy[i]->y);
	}
	
	for (int i = 9; i < 12; i++)
	{
		enemy[i]->x += (100*(i-6));
		enemy[i]->y += (300-(100*(i-9)));
		enemy[i]->sprite.setPosition(enemy[i]->x, enemy[i]->y);
	}
	
	enemy[12]->x += (250);
	enemy[12]->y += (400);
	enemy[12]->sprite.setPosition(enemy[12]->x, enemy[12]->y);
	
	for (int i = 0; i < numberOfEnemies; i++)
	{
		string t;
		if (enemy[i]->type == "alpha")
			t = "alpha";
		else if (enemy[i]->type == "beta")
			t = "beta";
		else if (enemy[i]->type == "gamma")
			t = "gamma";
		
		delete bomb[i];
		bomb[i] = new Bomb(enemy[i]->x, enemy[i]->y, t);
		enemy[i]->bomb = bomb[i];
	}
}

void Shapes::makeCross(int& numberOfEnemies, Enemy** &enemy, Bomb** &bomb)
{
	
	numberOfEnemies = 5;
	
	for (int i = 0; i < 5; i++)
	{
		int mod = rand() % 3;
		if (mod==0)
		enemy[i] = new Alpha;
		else if (mod==1)
		enemy[i] = new Beta;
		else
		enemy[i] = new Gamma;
	}
	
	
	for (int i = 0; i < 3; i++)
	{
		enemy[i]->x += (130*(i+1));
		enemy[i]->y += (130*(i+1));
		enemy[i]->sprite.setPosition(enemy[i]->x, enemy[i]->y);
	}
	
	enemy[3]->x += (130*3);
	enemy[3]->y += 130;
	enemy[3]->sprite.setPosition(enemy[3]->x, enemy[3]->y);
	
	
	enemy[4]->x += (130*1);
	enemy[4]->y += 390;
	enemy[4]->sprite.setPosition(enemy[4]->x, enemy[4]->y);
	
	for (int i = 0; i < numberOfEnemies; i++)
	{
		string t;
		if (enemy[i]->type == "alpha")
			t = "alpha";
		else if (enemy[i]->type == "beta")
			t = "beta";
		else if (enemy[i]->type == "gamma")
			t = "gamma";
		
		delete bomb[i];
		bomb[i] = new Bomb(enemy[i]->x, enemy[i]->y, t);
		enemy[i]->bomb = bomb[i];
	}

}

void Shapes::makeCircle(int& numberOfEnemies, Enemy** &enemy, Bomb** &bomb)
{
	
	numberOfEnemies = 10;
	
	for (int i = 0; i < 10; i++)
	{
		int mod = rand() % 3;
		if (mod==0)
		enemy[i] = new Alpha;
		else if (mod==1)
		enemy[i] = new Beta;
		else
		enemy[i] = new Gamma;
	}
	
	enemy[0]->x += (120*2);
	
	enemy[1]->x += (120*1);
	enemy[1]->y += (130*0.5);
	
	enemy[2]->x += (120*3);
	enemy[2]->y += (130*0.5);
	
	enemy[3]->x += (120*0);
	enemy[3]->y += (130);
	
	enemy[4]->x += (120*4);
	enemy[4]->y += (130);
	
	
	
	
	
	enemy[5]->x += (120*2);
	enemy[5]->y += (130*3);
	
	enemy[6]->x += (120*1);
	enemy[6]->y += (130*2.5);
	
	enemy[7]->x += (120*3);
	enemy[7]->y += (130*2.5);
	
	enemy[8]->x += (120*0);
	enemy[8]->y += (130)*2;
	
	enemy[9]->x += (120*4);
	enemy[9]->y += (130*2);
	
	
	for (int i = 0; i < 10; i++)
	{
		enemy[i]->sprite.setPosition(enemy[i]->x, enemy[i]->y);
	}
	
	for (int i = 0; i < numberOfEnemies; i++)
	{
		string t;
		if (enemy[i]->type == "alpha")
			t = "alpha";
		else if (enemy[i]->type == "beta")
			t = "beta";
		else if (enemy[i]->type == "gamma")
			t = "gamma";
		
		delete bomb[i];
		bomb[i] = new Bomb(enemy[i]->x, enemy[i]->y, t);
		enemy[i]->bomb = bomb[i];
	}
	
}

void Shapes::makeDiamond(int& numberOfEnemies, Enemy** &enemy, Bomb** &bomb)
{
	
	numberOfEnemies = 8;
	
	for (int i = 0; i < 8; i++)
	{
		int mod = rand() % 3;
		if (mod==0)
		enemy[i] = new Alpha;
		else if (mod==1)
		enemy[i] = new Beta;
		else
		enemy[i] = new Gamma;
	}
	
	enemy[0]->x += (120*2);
	
	enemy[1]->x += (120*1);
	enemy[1]->y += (130*0.8);
	
	enemy[2]->x += (120*3);
	enemy[2]->y += (130*0.8);
	
	enemy[3]->x += (120*0);
	enemy[3]->y += (130*1.6);
	
	enemy[4]->x += (120*4);
	enemy[4]->y += (130*1.6);
	
	
	enemy[5]->x += (120*2);
	enemy[5]->y += (130*3.2);
	
	enemy[6]->x += (120*1);
	enemy[6]->y += (130*2.4);
	
	enemy[7]->x += (120*3);
	enemy[7]->y += (130*2.4);
	
	for (int i = 0; i < 8; i++)
	{
		enemy[i]->sprite.setPosition(enemy[i]->x, enemy[i]->y);
	}
	
	for (int i = 0; i < numberOfEnemies; i++)
	{
		string t;
		if (enemy[i]->type == "alpha")
			t = "alpha";
		else if (enemy[i]->type == "beta")
			t = "beta";
		else if (enemy[i]->type == "gamma")
			t = "gamma";
		
		delete bomb[i];
		bomb[i] = new Bomb(enemy[i]->x, enemy[i]->y, t);
		enemy[i]->bomb = bomb[i];
	}
	
}

void Shapes::makeHeart(int& numberOfEnemies, Enemy** &enemy, Bomb** &bomb)
{
	
	numberOfEnemies = 12;
		
	for (int i = 0; i < 12; i++)
	{
		int mod = rand() % 3;
		if (mod==0)
		enemy[i] = new Alpha;
		else if (mod==1)
		enemy[i] = new Beta;
		else
		enemy[i] = new Gamma;
	}
	
	enemy[0]->x += (90*1);
	
	enemy[1]->x += (90*2);
	
	enemy[2]->x += (90*4);
	
	enemy[3]->x += (90*5);
	
	
	
	enemy[4]->x += (90*0);
	enemy[4]->y += (130*0.8);
	
	enemy[5]->x += (90*6);
	enemy[5]->y += (130*0.8);
	
	enemy[11]->x += (90*3);
	enemy[11]->y += (130*0.8);
	
	
	
	
	enemy[6]->x += (90*1);
	enemy[6]->y += (130*1.6);
	
	enemy[10]->x += (90*5);
	enemy[10]->y += (130*1.6);
	
	
	
	enemy[7]->x += (90*2);
	enemy[7]->y += (130*2.4);
	
	enemy[8]->x += (90*4);
	enemy[8]->y += (130*2.4);
	
	
	
	enemy[9]->x += (90*3);
	enemy[9]->y += (130*3.2);
	
	for (int i = 0; i < 12; i++)
	{
		enemy[i]->x -=20;
		enemy[i]->sprite.setPosition(enemy[i]->x, enemy[i]->y);
	}
	
	for (int i = 0; i < numberOfEnemies; i++)
	{
		string t;
		if (enemy[i]->type == "alpha")
			t = "alpha";
		else if (enemy[i]->type == "beta")
			t = "beta";
		else if (enemy[i]->type == "gamma")
			t = "gamma";
		
		delete bomb[i];
		bomb[i] = new Bomb(enemy[i]->x, enemy[i]->y, t);
		enemy[i]->bomb = bomb[i];
	}
}

void Shapes::makeFilledRectangle(int& numberOfEnemies, Enemy** &enemy, Bomb** &bomb)
{
	makeRectangle(numberOfEnemies, enemy, bomb);
	numberOfEnemies = 15;
	
	for (int i = 12; i < 15; i++)
	{
		int mod = rand() % 3;
		if (mod==0)
		enemy[i] = new Alpha;
		else if (mod==1)
		enemy[i] = new Beta;
		else
		enemy[i] = new Gamma;
	}
	
	for (int i = 12; i < 15; i++)
	{
		enemy[i]->x += (110*(i-11));
		enemy[i]->y += (110);
		enemy[i]->sprite.setPosition(enemy[i]->x, enemy[i]->y);
	}
	
	for (int i = 0; i < numberOfEnemies; i++)
	{
		string t;
		if (enemy[i]->type == "alpha")
			t = "alpha";
		else if (enemy[i]->type == "beta")
			t = "beta";
		else if (enemy[i]->type == "gamma")
			t = "gamma";
		
		delete bomb[i];
		bomb[i] = new Bomb(enemy[i]->x, enemy[i]->y, t);
		enemy[i]->bomb = bomb[i];
	}
	
}

void Shapes::makeFilledTriangle(int& numberOfEnemies, Enemy** &enemy, Bomb** &bomb)
{
	makeTriangle(numberOfEnemies, enemy, bomb);
	
	numberOfEnemies = 19;
	
	for (int i = 13; i < 19; i++)
	{
		int mod = rand() % 3;
		if (mod==0)
		enemy[i] = new Alpha;
		else if (mod==1)
		enemy[i] = new Beta;
		else
		enemy[i] = new Gamma;
	}
	
	
	for (int i = 13; i < 19; i++)
	{
		int z = 0, m = 0;
		if (i>16) {z = 100; m = 4;}
		enemy[i]->x += (100*((i-m)-12)+z);
		enemy[i]->y += (100+z);
		enemy[i]->sprite.setPosition(enemy[i]->x, enemy[i]->y);
	}
	
	for (int i = 0; i < numberOfEnemies; i++)
	{
		string t;
		if (enemy[i]->type == "alpha")
			t = "alpha";
		else if (enemy[i]->type == "beta")
			t = "beta";
		else if (enemy[i]->type == "gamma")
			t = "gamma";
		
		delete bomb[i];
		bomb[i] = new Bomb(enemy[i]->x, enemy[i]->y, t);
		enemy[i]->bomb = bomb[i];
	}
	
}
void Shapes::makeFilledCircle(int& numberOfEnemies, Enemy** &enemy, Bomb** &bomb)
{
	makeCircle(numberOfEnemies, enemy, bomb);
	numberOfEnemies = 15;
	
	for (int i = 10; i < 15; i++)
	{
		int mod = rand() % 3;
		if (mod==0)
		enemy[i] = new Alpha;
		else if (mod==1)
		enemy[i] = new Beta;
		else
		enemy[i] = new Gamma;
	}
	
	enemy[10]->x += (120*2);
	enemy[10]->y += (130*0.7);
	
	enemy[11]->x += (120*2);
	enemy[11]->y += (130*1.5);
	
	enemy[12]->x += (120*1);
	enemy[12]->y += (130*1.5);
	
	enemy[13]->x += (120*3);
	enemy[13]->y += (130*1.5);
	
	enemy[14]->x += (120*2);
	enemy[14]->y += (130*2.2);
	
	
	for (int i = 10; i < 15; i++)
	{
		enemy[i]->sprite.setPosition(enemy[i]->x, enemy[i]->y);
	}
	
	for (int i = 0; i < numberOfEnemies; i++)
	{
		string t;
		if (enemy[i]->type == "alpha")
			t = "alpha";
		else if (enemy[i]->type == "beta")
			t = "beta";
		else if (enemy[i]->type == "gamma")
			t = "gamma";
		
		delete bomb[i];
		bomb[i] = new Bomb(enemy[i]->x, enemy[i]->y, t);
		enemy[i]->bomb = bomb[i];
	}
	
}
void Shapes::makeFilledDiamond(int& numberOfEnemies, Enemy** &enemy, Bomb** &bomb)
{
	makeDiamond(numberOfEnemies, enemy, bomb);
	numberOfEnemies = 13;
	
	for (int i = 8; i < 13; i++)
	{
		int mod = rand() % 3;
		if (mod==0)
		enemy[i] = new Alpha;
		else if (mod==1)
		enemy[i] = new Beta;
		else
		enemy[i] = new Gamma;
	}
	
	enemy[8]->x += (120*2);
	enemy[8]->y += (130*0.8);
	
	enemy[10]->x += (120*2);
	enemy[10]->y += (130*1.6);
	
	enemy[11]->x += (120*1);
	enemy[11]->y += (130*1.6);
	
	enemy[12]->x += (120*3);
	enemy[12]->y += (130*1.6);
	
	enemy[9]->x += (120*2);
	enemy[9]->y += (130*2.4);
	
	for (int i = 8; i < 13; i++)
	{
		enemy[i]->sprite.setPosition(enemy[i]->x, enemy[i]->y);
	}
	
	for (int i = 0; i < numberOfEnemies; i++)
	{
		string t;
		if (enemy[i]->type == "alpha")
			t = "alpha";
		else if (enemy[i]->type == "beta")
			t = "beta";
		else if (enemy[i]->type == "gamma")
			t = "gamma";
		
		delete bomb[i];
		bomb[i] = new Bomb(enemy[i]->x, enemy[i]->y, t);
		enemy[i]->bomb = bomb[i];
	}
}
void Shapes::makeFilledHeart(int& numberOfEnemies, Enemy** &enemy, Bomb** &bomb)
{
	makeHeart(numberOfEnemies, enemy, bomb);
	numberOfEnemies = 16;
	
	for (int i = 12; i < 16; i++)
	{
		int mod = rand() % 3;
		if (mod==0)
		enemy[i] = new Alpha;
		else if (mod==1)
		enemy[i] = new Beta;
		else
		enemy[i] = new Gamma;
	}
	
	enemy[12]->x += (90*1.5);
	enemy[12]->y += (130*0.8);
	
	enemy[13]->x += (90*4.5);
	enemy[13]->y += (130*0.8);
	
	enemy[14]->x += (200);
	enemy[14]->y += (130*1.6);
	
	enemy[15]->x += (340);
	enemy[15]->y += (130*1.6);
	
	for (int i = 12; i < 16; i++)
	{
		enemy[i]->x -=20;
		enemy[i]->sprite.setPosition(enemy[i]->x, enemy[i]->y);
	}
	
	for (int i = 0; i < numberOfEnemies; i++)
	{
		string t;
		if (enemy[i]->type == "alpha")
			t = "alpha";
		else if (enemy[i]->type == "beta")
			t = "beta";
		else if (enemy[i]->type == "gamma")
			t = "gamma";
		
		delete bomb[i];
		bomb[i] = new Bomb(enemy[i]->x, enemy[i]->y, t);
		enemy[i]->bomb = bomb[i];
	}
}
#endif
