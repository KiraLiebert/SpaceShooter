#ifndef GAMMA_H
#define GAMMA_H

#include "Gamma.h"

Gamma::Gamma()
{
	tex.loadFromFile("img/gamma.png");
	sprite.setTexture(tex);
	
	x=40;
	y=20;
	bombDrop = false;
	timed = true;
	type = "gamma";
	
	sprite.setPosition(x,y);
	int r = rand() % 10;
	
	bomb = new Bomb(x,y, "img/bomb3.png");
}

void Gamma::move()
{
	int s = 500;
	movement++;
	int mod = movement % s;
	
	if ((mod<(s/4))&&(mod%(s/20)==0))
		x+=1;
	else if ((mod<(s/2))&&(mod%(s/20)==0))
		y+=1;
	else if ((mod<(s*3/4.0))&&(mod%(s/20)==0))
		x-=1;
	else if ((mod<s)&&(mod%(s/20)==0))
		y-=1;
	sprite.setPosition(x,y);
	if (movement>s)
		movement = 1;
}

void Gamma::fire(float time)
{
	
}

#endif
