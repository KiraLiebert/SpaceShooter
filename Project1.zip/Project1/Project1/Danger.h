#pragma once
#include"AddOn.h"
class Danger : public AddOn
{
public:
	//attributes
	bool active,timed;
	
public:
	Danger();
	void fall(float time);
	~Danger(){}
};
