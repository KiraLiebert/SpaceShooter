#ifndef DRAGON_H
#define DRAGON_H

#include "Dragon.h"

Dragon::Dragon()
{
	tex.loadFromFile("img/dragon1.png");
	sprite.setTexture(tex);
	
	x=200;
	y=40;
	
	texR.loadFromFile("img/fireR.png");
	spriteR.setTexture(texR);
	texL.loadFromFile("img/fireL.png");
	spriteL.setTexture(texL);
	texC.loadFromFile("img/fire.png");
	spriteC.setTexture(texC);
	
	sprite.setPosition(x,y);
	
	bomb = new Bomb(x+77,y+150, "img/fireR.png");
	type = "dragon";
}

void Dragon::move()
{
	
}

void Dragon::fire(float time)
{
	
	if (time == 0)
	{
		bomb->x = x + 103;
		bomb->y = y + 220;
		bomb->sprite = spriteC;
	}
	else if (time == 1)
	{
		bomb->x = x - 220;
		bomb->y = y + 220;
		bomb->sprite = spriteL;
	}
	else
	{
		bomb->x = x + 107;
		bomb->y = y + 220;
		bomb->sprite = spriteR;
	}
	bomb->sprite.setPosition (bomb->x, bomb->y);
	bomb->sprite.setScale (1.25,1.25);
}

#endif
