#pragma once
#include "Enemy.h"
class Invader : public Enemy
{
public:
	//attributes
	string invType;
	int movement;
	
public:
	Invader();
};
