#ifndef PLAYER_H
#define PLAYER_H
using namespace std;
#include "Player.h"
#include<string>
#include<string.h>
Player::Player()
{

	path = choosePath();

	tex.loadFromFile(path);
	sprite.setTexture(tex);

	texR.loadFromFile("img/player_r.png");
	spriteR.setTexture(texR);

	texL.loadFromFile("img/player_l.png");
	spriteL.setTexture(texL);


	x = 600;
	y = 600;

	sprite.setPosition(x, y);
	sprite.setScale(0.75, 0.75);
	spriteR.setScale(0.75, 0.75);
	spriteL.setScale(0.75, 0.75);

	speed = 0.3;
	bullet = new Bullet(x, y);
	lives = 5;
}

string Player::choosePath()
{
	string p;
	p = "img/player.png";

	/*
	srand(time(0));
	int i = rand()%13;
	string p;

	if (i==0)
		p = "im/player.png";
	else if (i==1)
		p = "im/player1.png";
	else if (i==2)
		p = "im/player2.png";
	else if (i==3)
		p = "im/player3.png";
	else if (i==4)
		p = "im/player4.png";
	else if (i==5)
		p = "im/player5.png";
	else if (i==6)
		p = "im/player6.png";
	else if (i==7)
		p = "im/player7.png";
	else if (i==8)
		p = "im/player8.png";
	else if (i==9)
		p = "im/player9.png";
	else if (i==10)
		p = "im/player10.png";
	else if (i==11)
		p = "im/player11.png";
	else if (i==12)
		p = "im/player12.png";
	*/
	return p;
}

void Player::move(std::string s)
{
	if (s == "l")
		x += (-1 * speed);
	else if (s == "r")
		x += (1 * speed);

	if (s == "u")
		y += (-1 * speed);
	else if (s == "d")
		y += (1 * speed);

	if (x > 603)
		x = -37;
	else if (x < -37)
		x = 603;

	if (y > 640)
		y = 0;
	else if (y < 0)
		y = 640;

	sprite.setPosition(x, y);
}

bool Player::fire(std::string s) {
	if (bullet->x == 25 && bullet->y == -40) {
		//bullet->x = x;
		//bullet->y = y;
		delete bullet;
		bullet = new Bullet(x, y);
	}
	if (s == "right") {
		if (fireRight()) {
			delete bullet;
			bullet = new Bullet(-10, -10);
			return 1;
		}
	}
	else if (s == "left")
		if (fireLeft()) {
			delete bullet;
			bullet = new Bullet(-10, -10);
			return 1;
		}

	if (s == "")
	{
		bullet->y -= 2;

		bullet->sprite.move(0, -2);

		if (bullet->y < 0)
		{
			delete bullet;
			bullet = new Bullet(-10, -10);
			bulletCount++;
			return 1;
		}
	}
	return 0;
}

bool Player::fireRight() {

	if (!right)
	{
		delete bullet;
		bullet = new Bullet(x + 46, y, "img/bulletRight.png");
	}
	right = true;
	bullet->y -= 2;
	bullet->x += 2;

	bullet->sprite.move(2, -2);

	if (bullet->y < 0)
	{
		delete bullet;
		right = false;
		left = false;
		bullet = new Bullet(x, y, "img/bullet.png");
		return 1;
	}
	return 0;
}

bool Player::fireLeft() {

	if (!left)
	{
		delete bullet;
		bullet = new Bullet(x - 80, y, "img/bulletLeft.png");
	}

	left = true;
	bullet->y -= 2;
	bullet->x -= 2;

	bullet->sprite.move(-2, -2);

	if (bullet->y < 0)
	{
		delete bullet;
		right = false;
		left = false;
		bullet = new Bullet(x, y, "img/bullet.png");
		return 1;
	}
	return 0;
}

Player::~Player()
{
	delete bullet;
	bullet = NULL;
}

#endif
