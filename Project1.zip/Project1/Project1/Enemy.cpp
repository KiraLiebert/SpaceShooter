#ifndef ENEMY_H
#define ENEMY_H

#include "Enemy.h"

Enemy::Enemy()
{
	
}

Enemy::~Enemy()
{
	
}

#endif
