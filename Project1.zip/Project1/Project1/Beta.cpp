#ifndef BETA_H
#define BETA_H

#include "Beta.h"

Beta::Beta()
{
	tex.loadFromFile("img/beta.png");
	sprite.setTexture(tex);
	
	x=40;
	y=20;
	bombDrop = false;
	timed = true;
	type = "beta";
	
	sprite.setPosition(x,y);
	int r = rand() % 10;
	
	bomb = new Bomb(x,y, "img/bomb2.png");
}

void Beta::move()
{
	int s = 800;
	movement++;
	int mod = movement % s;
	
	if ((mod<(s/4))&&(mod%(s/20)==0))
		x+=1;
	else if ((mod<(s/2))&&(mod%(s/20)==0))
		y+=1;
	else if ((mod<(s*3/4.0))&&(mod%(s/20)==0))
		x-=1;
	else if ((mod<s)&&(mod%(s/20)==0))
		y-=1;
	sprite.setPosition(x,y);
	if (movement>s)
		movement = 1;
}

void Beta::fire(float time)
{
	
}

#endif
