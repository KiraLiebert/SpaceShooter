#ifndef BULLET_H
#define BULLET_H

#include "Bullet.h"

Bullet::Bullet(int xx, int yy, std::string s)
{
	tex.loadFromFile(s);
	sprite.setTexture(tex);
	x = xx + 35;
	y = yy - 30;
	sprite.setPosition(x,y);
}

#endif
