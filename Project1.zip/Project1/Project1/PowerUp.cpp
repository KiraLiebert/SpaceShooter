#ifndef POWERUP_H
#define POWERUP_H

#include "PowerUp.h"

PowerUp::PowerUp()
{
	tex.loadFromFile("img/powerup.png");
	sprite.setTexture(tex);
	
	x=rand()% 620 + 10;
	y=0;
	
	sprite.setPosition(x,y);
	sprite.setScale(1,1);
	active = timed = false;
	
	type = "powerup";
}

void PowerUp::fall(float time)
{
	y+=0.1;
	sprite.setPosition(x,y);
}
#endif
