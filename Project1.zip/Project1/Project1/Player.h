#pragma once
#include "Bullet.h"
#include <SFML/Graphics.hpp>
#include<string.h>
using namespace sf;

//#include "AddOn.h"
#include "Lives.h"
#include "Fire.h"
#include "Danger.h"

class Player
{
public:
	Texture tex;
	Sprite sprite;
	
	Texture texR;
	Sprite spriteR;
	
	Texture texL;
	Sprite spriteL;
	
	float speed;
	float x,y;
	Bullet* bullet;
	int lives;
	std::string path;
	bool left;
	bool right;
	int bulletCount;
	
public:
	
	Player();
	void move(std::string s);
	bool checkCollision(float, float);
	string choosePath();
	
	bool fireRight();
	bool fireLeft();
	bool fire(std::string s = "");
	
	~Player();
};
