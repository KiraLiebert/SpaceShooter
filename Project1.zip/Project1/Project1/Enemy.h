#pragma once
#include "Bomb.h"
#include <SFML/Graphics.hpp>
#include<string.h>
using namespace sf;

class Enemy
{
public:
	Texture tex;
	Sprite sprite;
	float x,y;
	Bomb* bomb;
	std::string type;
	
public:
	
	Enemy();
	virtual void move() = 0;
	virtual void fire(float) = 0;
	virtual ~Enemy();
};
