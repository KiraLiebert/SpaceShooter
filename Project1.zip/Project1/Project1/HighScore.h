#pragma once
#include <iostream>
using namespace std;
#include<string>
#include<string.h>
class HighScore
{
public:
	string fileName = "HighScores.txt";
	
	string lowestName;
	int lowestScore;
	
	string firstHighest;
	int firstScore;
	string secondHighest;
	int secondScore;
	string thirdHighest;
	int thirdScore;
	
public:
	HighScore();
	
	void Input(string name, int score);
	
	int getScore(string name);
	
	void Display();
	
	string* getScores();
	
	string* getNames();
	
	int Count();
	
	void Delete(string name);
	
	bool Search(string name);
	
	void Replace(string updateName, int score);
	
	void Replace(string updateName, int score, string oldName);
	
	void Sort();
	
	~HighScore(){}
};
