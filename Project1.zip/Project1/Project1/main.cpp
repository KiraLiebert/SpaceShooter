#include "Game.h"


int main()
{
	Game g;
	g.start_game();
	//	Menu m;
	//	m.display_menu();
	return 0;
}
