#include "Fire.h"
#ifndef FIRE_H
#define FIRE_H


Fire::Fire()
{
	tex.loadFromFile("img/fire2.png");
	sprite.setTexture(tex);
	
	x=rand()% 620 + 10;
	y=0;
	
	sprite.setPosition(x,y);
	sprite.setScale(1,1);
	active = timed = false;
	
	type = "fire";
}

void Fire::fall(float time)
{
	y+=0.1;
	sprite.setPosition(x,y);
}
#endif
