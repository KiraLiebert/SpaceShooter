#include "HighScore.h"
#include <fstream>
using namespace std;
#include<string>
#include<string.h>
#include<iostream>
#include<vector>
HighScore::HighScore()
{
	fstream MyFile(fileName);
	MyFile.close();
}

void HighScore::Input(string name, int score)
{
	
	fstream MyFile(fileName, MyFile.out | MyFile.app);
	
	MyFile<<name<<endl;
	MyFile<<score<<endl;
	MyFile.close();
}

void HighScore::Display()
{
	string myText;
	ifstream MyReadFile(fileName);
	
	while (getline (MyReadFile, myText))
		cout << myText <<endl;
	
	MyReadFile.close();
}

int HighScore::Count()
{
	string myText;
	ifstream MyReadFile(fileName);
	
	int count = 0;
	
	while (getline (MyReadFile, myText))
		count++;
	
	MyReadFile.close();
	
	return count/2;
}

void HighScore::Delete(string name)
{
	
	string myText;
	ifstream MyReadFile(fileName);
	
	fstream MyFile("HighScores1.txt", MyFile.out);
	
	bool found = false;
	int count = 0;
	while (getline (MyReadFile, myText))
	{
		count++;
		
		if ((found == true)&&(count%2 == 1))
			found = false;
		
		if (count%2 == 1)
			if(myText == name)
				found = true;
		
		if (found == false)
			MyFile << myText <<endl;
	}
	
	MyFile.close();
	MyReadFile.close();
	
	ifstream MyReadFile2("HighScores1.txt");
	
	fstream MyFile2(fileName, MyFile.out);
	
	while (getline (MyReadFile2, myText))
			MyFile2 << myText <<endl;
	
	MyFile2.close();
	MyReadFile2.close();
}

bool HighScore::Search(string name)
{
	
	string myText;
	
	ifstream MyReadFile(fileName);
	
	bool found = false;
	int count = 0;
	while (getline (MyReadFile, myText))
	{
		count++;
		
		if ((found == true)&&(count%2 == 0))
			break;
		
		if (count%2 == 1)
			if(myText == name)
				found = true;
		
		if (found == true)
			break;
	}
	MyReadFile.close();
	
	return found;
}

int HighScore::getScore(string name)
{
	string myText;
	
	ifstream MyReadFile(fileName);
	
	bool found = false;
	int count = 0;
	while (getline (MyReadFile, myText))
	{
		count++;
		
		if (count%2 == 1)
			if(myText == name)
				found = true;
		
		if ((found == true)&&(count%2 == 0))
		{
			int score = stoi(myText);
			return score;
		}
	}
	MyReadFile.close();
	
	return -1;
}

void HighScore::Replace(string replacedName, int replacedScore)
{
	string myText;
	
	ifstream MyReadFile(fileName);
	
	fstream MyFile("HighScores1.txt", MyFile.out);
	
	bool found = false;
	int count = 0;
	while (getline (MyReadFile, myText))
	{
		count++;
		
		if (found)
		{
			MyFile<<replacedName<<endl;
			MyFile<<replacedScore<<endl;
			break;
		}
		if (count%2 == 1)
			if(myText == lowestName)
				found = true;
		
		if (!found)
			MyFile << myText <<endl;
	}
	
	MyFile.close();
	MyReadFile.close();
	
	ifstream MyReadFile2("HighScores1.txt");
	
	fstream MyFile2(fileName, MyFile.out);
	
	while (getline (MyReadFile2, myText))
	{
			MyFile2 << myText <<endl;
	}
	
	MyFile2.close();
	MyReadFile2.close();
}

void HighScore::Replace(string replacedName, int replacedScore, string oldName)
{
	string myText;
	
	ifstream MyReadFile(fileName);
	
	fstream MyFile("HighScores1.txt", MyFile.out);
	
	bool found = false;
	int count = 0;
	while (getline (MyReadFile, myText))
	{
		count++;
		
		if ((found == true)&&(count%2 == 1))
		{
			MyFile<<replacedName<<endl;
			MyFile<<replacedScore<<endl;
			found = false;
		}
		if (count%2 == 1)
			if(myText == oldName)
				found = true;
		
		if (found == false)
			MyFile << myText <<endl;
	}
	
	MyFile.close();
	MyReadFile.close();
	
	ifstream MyReadFile2("HighScores1.txt");
	
	fstream MyFile2(fileName, MyFile.out);
	
	while (getline (MyReadFile2, myText))
	{
			MyFile2 << myText <<endl;
	}
	
	MyFile2.close();
	MyReadFile2.close();
}

string* HighScore::getScores()
{
	int count = Count();
	
	string* scores = new string[count];
	
	string myText;
	ifstream MyReadFile(fileName);
	
	int c = 0;
	
	while (getline (MyReadFile, myText))
	{
		c++;
		if (c%2 == 0)
			scores[(c/2)-1] = myText;
	}
	
	return scores;
}
	
string* HighScore::getNames()
{
	int count = Count();
	
	string* names = new string[count];
	
	string myText;
	ifstream MyReadFile(fileName);
	
	int c = 0;
	
	while (getline (MyReadFile, myText))
	{
		c++;
		if (c%2 != 0)
			names[c/2] = myText;
	}
	MyReadFile.close();
	
	return names;
}

void HighScore::Sort()
{
	int const count = Count();
	vector<int> scores(count);
	vector<std::string> names(count);

	
	string myText;
	ifstream MyReadFile(fileName);
	
	int c = 0;
	
	while (getline (MyReadFile, myText))
	{
		c++;
		if (c%2 == 0)
			scores[(c/2)-1] = stoi(myText);
		else
			names[c/2] = myText;
	}
	MyReadFile.close();
	
	for (int i = 0; i < count; i++)
	{
		for(int j = 0; j < i; j++)
		{
			if(scores[i]>scores[j])
			{
				int temp = scores[i];
				scores[i] = scores[j];
				scores[j] = temp;
				string temp2 = names[i];
				names[i] = names[j];
				names[j] = temp2;
			}
		}
	}
	
	ofstream MyFile2(fileName);
	for (int i = 0; i < count; i++)
	{
		MyFile2 << names[i] <<endl;
		MyFile2 << scores[i] <<endl;
	}
	
	if (count>0)
	{
		firstHighest = names[0];
		firstScore = scores[0];
	}
	if (count>1)
	{
		secondHighest = names[1];
		secondScore = scores[1];
	}
	if (count>2)
	{
		thirdHighest = names[2];
		thirdScore = scores[2];
	}
	
	lowestName = names[count-1];
	lowestScore = scores[count-1];
	
	MyFile2.close();
}
