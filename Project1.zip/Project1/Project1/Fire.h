#pragma once
#include "AddOn.h"
class Fire : public AddOn
{
public:
	//attributes
	bool active,timed;
	
public:
	Fire();
	void fall(float time);
	~Fire(){}
};
