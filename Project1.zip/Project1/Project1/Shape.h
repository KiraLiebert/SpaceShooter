#pragma once
#include <SFML/Graphics.hpp>
#include <time.h>

#include <iostream>
using namespace std;

#include "Enemy.h"
#include "Alpha.h"
#include "Beta.h"
#include "Gamma.h"
#include "Monster.h"
#include "Dragon.h"

using namespace sf;

class Shapes
{
	
public:
	
	void makeRectangle(int&, Enemy** &enemy, Bomb** &bomb);
	void makeTriangle(int&, Enemy** &enemy, Bomb** &bomb);
	void makeCross(int&, Enemy** &enemy, Bomb** &bomb);
	void makeCircle(int&, Enemy** &enemy, Bomb** &bomb);
	void makeDiamond(int&, Enemy** &enemy, Bomb** &bomb);
	void makeHeart(int&, Enemy** &enemy, Bomb** &bomb);
	
	void makeFilledRectangle(int&, Enemy** &enemy, Bomb** &bomb);
	void makeFilledTriangle(int&, Enemy** &enemy, Bomb** &bomb);
	void makeFilledCircle(int&, Enemy** &enemy, Bomb** &bomb);
	void makeFilledDiamond(int&, Enemy** &enemy, Bomb** &bomb);
	void makeFilledHeart(int&, Enemy** &enemy, Bomb** &bomb);
	
};
