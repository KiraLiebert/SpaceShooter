#pragma once
#include <SFML/Graphics.hpp>
#include<string.h>
using namespace sf;

class Bullet
{
public:

	Texture tex;
	Sprite sprite;
	float speed=0.1;
	float x,y;
	
public:
	Bullet(int xx, int yy, std::string s = "img/bullet.png");
};
