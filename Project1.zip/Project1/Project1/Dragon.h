#pragma once
#include "Enemy.h"
class Dragon : public Enemy
{

public:
	//attributes
	Texture texL;
	Sprite spriteL;
	
	Texture texR;
	Sprite spriteR;
	
	Texture texC;
	Sprite spriteC;
	
	
public:
	Dragon();
	void move();
	void fire(float);
	~Dragon(){}
};
