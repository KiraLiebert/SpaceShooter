#ifndef GAME_H
#define GAME_H
#include "Game.h"
#include<fstream>
Game::Game()
{
	//loading all the sprites from files.
	bg_texture.loadFromFile("img/background.jpg");
	background.setTexture(bg_texture);
	side_tex.loadFromFile("img/side.png");
	sideBackground.setTexture(side_tex);

	sidemenu_tex.loadFromFile("img/sidemenu.png");
	sideMenu.setTexture(sidemenu_tex);

	g.loadFromFile("img/gameover.png");
	gameOver.setTexture(g);

	obj1tex.loadFromFile("img/animation1.png");
	obj1.setTexture(obj1tex);
	obj2tex.loadFromFile("img/animation2.png");
	obj2.setTexture(obj2tex);

	font.loadFromFile("arial.ttf");

	sideBackground.move(640, 0);
	sideMenu.move(670, 100);

	gameMusic.openFromFile("music/game.wav");
	menuMusic.openFromFile("music/menu.wav");

	initializeVariables();
	readGame();
}

void Game::start_game()
{
	//Setting window and music.
	srand(time(0));
	RenderWindow window(VideoMode(960, 640), title);
	Clock clock;
	timer = 0;
	gameMusic.setLoop(true);
	menuMusic.setLoop(true);

	while (window.isOpen())
	{

		float time = clock.getElapsedTime().asSeconds();
		clock.restart();

		if (!pause)
			timer += time;

		Event e;
		//Saving the game in file before closing the window.
		while (window.pollEvent(e))
		{
			if (e.type == Event::Closed)
			{
				if (end)
					initializeVariables();
				writeGame();
				window.close();
				return;
			}
		}

		if (!end)
		{
			//If game is paused display menu.
			if (pause)
			{
				gameMusic.pause();
				menuMusic.play();
				int temp = m.display_menu(window, e);
				menuMusic.pause();
				gameMusic.play();
				if (temp == 0)
				{
					writeGame();
					window.close();
				}
				else
					showMenu(temp);
			}

			if (!pause)
			{
				chooseLevel();
				checkAnimation();
			}

			//Up, Left, Right and Down movements of the player
			if (p && !animation)
			{
				if (Keyboard::isKeyPressed(Keyboard::A))
				{
					p->move("l");
					left = true;
				}
				if (Keyboard::isKeyPressed(Keyboard::D))
				{
					p->move("r");
					right = true;
				}
				if (Keyboard::isKeyPressed(Keyboard::W))
				{
					p->move("u");
					up = true;
				}
				if (Keyboard::isKeyPressed(Keyboard::S))
				{
					p->move("d");
					down = true;
				}
				if (Keyboard::isKeyPressed(Keyboard::Space))
				{
					if (fireStart == false) {
						if ((up && right) || (p->right))
							p->fire("right");
						else if ((up && left) || (p->left))
							p->fire("left");
						else
							//else if (fireStart != 1)
							p->fire();
						fireStart = true;
					}
				}
				if (fireStart) {
					if ((up && right) || (p->right))
						p->fire("right");
					else if ((up && left) || (p->left))
						p->fire("left");
					else if (p->fire())
						fireStart = 0;
					//else if (fireStart != 1)
				/*if (p->fire())
					fireStart = 0;*/
				}


			}

			//Pausing the game with P button.
			if (e.type == Event::KeyReleased)
				if (e.key.code == Keyboard::P) pause = true;

			callFunctions();
		}

		if (end)
		{
			if (!pause)
			{
				gameMusic.pause();
				menuMusic.play();
				pause = true;
			}
			if (Keyboard::isKeyPressed(Keyboard::M))
			{
				initializeVariables();
				m.username = "";
			}
		}

		window.clear(Color::Black);
		window.draw(background);
		//Drawing all the sprites of the game through the function.
		drawObjects(window);

		window.display();
	}
}

void Game::showMenu(int temp)
{
	// If new game is selected delete all the previous declared variables and initialize them.
	if (temp == 1)
	{
		for (int i = 0; i < numberOfEnemies; i++)
		{
			if (enemy[i]) delete enemy[i];
			if (bomb[i]) delete bomb[i];
		}

		initializeVariables();
		username = m.username;
	}

	m.game = false;
	m.selected = false;
	bg_texture = m.bg_texture;
	background.setTexture(bg_texture);
	pause = false;
}

//Checking Level and Giving enemy shapes according to the level.
void Game::chooseLevel()
{
	if (!nextLevel)
	{
		for (int i = 0; i < numberOfEnemies; i++)
		{
			if (enemy[i] != NULL) break;
			if (i == numberOfEnemies - 1) nextLevel = true;
		}
	}
	if (nextLevel)
	{
		nextLevel = false;
		level++;

		if (level == 1) s.makeRectangle(numberOfEnemies, enemy, bomb);
		else if (level == 2) s.makeTriangle(numberOfEnemies, enemy, bomb);
		else if (level == 3) s.makeCross(numberOfEnemies, enemy, bomb);
		else if (level == 4) s.makeCircle(numberOfEnemies, enemy, bomb);
		else if (level == 5) s.makeHeart(numberOfEnemies, enemy, bomb);
		else if (level == 6) s.makeDiamond(numberOfEnemies, enemy, bomb);
		else if (level == 7) s.makeFilledTriangle(numberOfEnemies, enemy, bomb);
		else if (level == 8) s.makeFilledRectangle(numberOfEnemies, enemy, bomb);
		else if (level == 9) s.makeFilledCircle(numberOfEnemies, enemy, bomb);
		else if (level == 10) s.makeFilledHeart(numberOfEnemies, enemy, bomb);
		else if (level == 11) s.makeFilledDiamond(numberOfEnemies, enemy, bomb);
		else if (level == 12) end = true;

		animationStart = true;

		if (level < 4) phase = 1;
		else if (level < 7) phase = 2;
		else phase = 3;
	}
}

void Game::checkAnimation()
{
	if (animationStart == true)
	{
		animation = true;
		animationStart = false;
		obj1X = 0;
		obj2X = 547;
		p->x = 280;
		p->y = 300;
		p->sprite.setPosition(p->x, p->y);
	}

	if (animation) showAnimation();

	int selectTime = int(timer) % 30;

	if (selectTime > 20) Invaderpause = true;

	else if (Invaderpause)
	{
		Invaderpause = false;
		if (enemy2->type == "monster") score += 100;
		else if (enemy2->type == "dragon") score += 200;

		delete enemy2;
		enemy2 = NULL;
	}

	if ((Invaderpause == true) && (enemy2 == NULL))
	{
		int mod = rand() % 2;
		if (mod == 0) enemy2 = new Monster;
		else enemy2 = new Dragon;
		nextLevelPause = true;
		nextLevelTimer = timer + 2;
	}
}

void Game::showAnimation()
{

	if (obj1X >= obj2X - 93) reverse = true;

	if (!reverse && animation)
	{
		obj1X += 0.1;
		obj1.setPosition(obj1X, 300);

		obj2X -= 0.1;
		obj2.setPosition(obj2X, 300);
	}

	if (reverse && animation)
	{
		p->y += 0.3;
		p->sprite.setPosition(p->x, p->y);

		obj1X -= 0.3;
		obj1.setPosition(obj1X, 300);

		obj2X += 0.3;
		obj2.setPosition(obj2X, 300);
	}

	if (obj1X <= 0)
	{
		reverse = false;
		animation = false;
		nextLevelPause = true;
		nextLevelTimer = timer + 3;
		if (p)
			p->sprite.setColor(sf::Color(250, 250, 250, 100));
	}
}

void Game::callFunctions()
{
	if (p && !animation)
	{
		if (!Invaderpause)
		{
			if (!nextLevelPause)
			{
				/*if ((up && right)||(p->right)) p->fire("right");
				else if ((up && left)||(p->left)) p->fire("left");
				else p->fire();*/
			}
			else
			{
				p->right = p->left = false;
			}

			if (addOns) addOns->fall(timer);
			if (!nextLevelPause) checkAddOns();

			for (int i = 0; i < numberOfEnemies; i++)
			{
				if (p)
				{
					if (bomb[i])
						bomb[i]->fire(timer);

					if (enemy[i])
					{
						enemy[i]->move();
						enemy[i]->fire(timer);
						destroyEnemy(enemy[i]);

						if (enemy[i] && !nextLevelPause && !powerupStart) destroyPlayer(enemy[i]);
					}
					if (bomb[i] && p && !nextLevelPause && !powerupStart)
					{
						destroyPlayer(bomb[i]);
					}
				}
			}
		}
		else
		{
			enemy2->move();
			if (enemy2->type == "dragon") checkPlayerCordinates();
			else enemy2->fire(timer);
			if (!nextLevelPause)
				destroyPlayer(enemy2);
		}
	}

	if (nextLevelTimer < timer)
	{
		nextLevelPause = false;
		if (p)
			p->sprite.setColor(sf::Color(250, 250, 250, 250));
	}
}

void Game::checkAddOns()
{
	int t = timer + 1;
	if (!addOns && (t % 13 == 0))
	{
		int mod = rand() % 4;
		if (mod == 0) addOns = new Danger;
		else if (mod == 1) addOns = new Lives;
		else if (mod == 2) addOns = new Fire;
		else if (mod == 3) addOns = new PowerUp;
	}

	if (addOns)
	{
		if ((p->x < (addOns->x) + 20) && (p->x > (addOns->x) - 75) && ((p->y < (addOns->y) + 20) && (p->y > (addOns->y) - 75)))
		{
			if (addOns->type == "lives") p->lives++;
			else if (addOns->type == "danger")
			{
				p->lives--;
				if (p->lives == 0)
				{
					delete p;
					p = NULL;
					end = true;
				}
				if (p)
				{
					p->x = 307;
					p->y = 560;
					p->sprite.setPosition(307, 560);
					nextLevelPause = true;
					nextLevelTimer = timer + 2;
					p->sprite.setColor(sf::Color(250, 250, 250, 100));
				}
			}
			else if (addOns->type == "fire")
			{
				//fireStart = true;
				//fireTimer = timer + 5;
			}
			else if (addOns->type == "powerup")
			{
				powerupStart = true;
				powerupTimer = timer + 20;
			}

			delete addOns;
			addOns = NULL;
		}
	}

	if (addOns)
		if (addOns->y > 700)
		{
			if (addOns->type == "danger") score += 50;

			delete addOns;
			addOns = NULL;
		}

	//if (fireStart && fireTimer<timer) fireStart = false;
	if (powerupStart && powerupTimer < timer) powerupStart = false;
}

void Game::destroyEnemy(Enemy*& ee)
{
	if ((ee->x < (p->bullet->x)) && (ee->x > (p->bullet->x) - 80) && ((ee->y < (p->bullet->y)) && (ee->y > (p->bullet->y) - 80)))
	{
		if (ee->type == "alpha") score += (phase * 10);
		else if (ee->type == "beta") score += (phase * 20);
		else if (ee->type == "gamma") score += (phase * 30);

		ee->bomb->p = true;

		delete ee;
		ee = NULL;
		if (fireStart) {
			delete p->bullet;
			p->bullet = new Bullet(-10, -10);
			fireStart = 0;
			//p->bullet->sprite.setPosition(p->bullet->x, p->bullet->y);
		}
		else if (!fireStart)
		{
			p->bullet->y = (p->y) - 30;
			p->bullet->x = (p->x) + 33;
			p->bullet->sprite.setPosition(p->bullet->x, p->bullet->y);
		}

	}
}

void Game::destroyPlayer(Enemy*& ee)
{
	bool collide = false;

	if ((ee->type == "monster") && ((p->x < (ee->bomb->x) + 10) && (p->x > (ee->bomb->x) - 10) && (p->y > 100)))
		collide = true;
	else if (((ee->type == "alpha") || (ee->type == "beta") || (ee->type == "gamma")) && ((p->x < (ee->bomb->x) + 20) && (p->x > (ee->bomb->x) - 75) && ((p->y < (ee->bomb->y) + 20) && (p->y > (ee->bomb->y) - 75))))
		collide = true;
	else if (ee->type == "dragon")
	{
		if (p->y > 260)
		{
			if ((p->y <= (1.2 * p->x) - 70) && (p->y >= (1.2 * p->x) - 170)) collide = true;
			else if ((p->y <= (600 - (1.2 * p->x))) && (p->y >= (500 - (1.2 * p->x)))) collide = true;
			else if ((p->x >= (240)) && (p->x <= (330))) collide = true;
		}
	}


	if (((ee->type == "alpha") || (ee->type == "beta") || (ee->type == "gamma")) && ((p->x < (ee->x) + 80) && (p->x > (ee->x) - 75) && ((p->y < (ee->y) + 80) && (p->y > (ee->y) - 75))))
		collide = true;
	else if ((ee->type == "monster") && ((p->x < (ee->x) + 200) && (p->x > (ee->x) - 75) && ((p->y < (ee->y) + 200) && (p->y > (ee->y) - 75))))
		collide = true;
	else if ((ee->type == "dragon") && ((p->x < (ee->x) + 240) && (p->x > (ee->x) - 75) && ((p->y < (ee->y) + 240) && (p->y > (ee->y) - 75))))
		collide = true;

	if (collide)
	{
		p->lives--;
		if (p->lives == 0)
		{
			delete p;
			p = NULL;
			end = true;
		}
		if (p)
		{
			p->x = 307;
			p->y = 560;
			p->sprite.setPosition(307, 560);
			nextLevelPause = true;
			nextLevelTimer = timer + 2;
			p->sprite.setColor(sf::Color(250, 250, 250, 100));
		}
	}
}

void Game::destroyPlayer(Bomb*& bb)
{
	bool collide = false;

	if (((bb->type == "alpha") || (bb->type == "beta") || (bb->type == "gamma")) && ((p->x < (bb->x) + 20) && (p->x > (bb->x) - 75) && ((p->y < (bb->y) + 20) && (p->y > (bb->y) - 75))))
		collide = true;


	if (collide)
	{
		p->lives--;
		if (p->lives == 0)
		{
			delete p;
			p = NULL;
			end = true;
		}
		if (p)
		{
			p->x = 307;
			p->y = 560;
			p->sprite.setPosition(307, 560);
			nextLevelPause = true;
			nextLevelTimer = timer + 2;
			p->sprite.setColor(sf::Color(250, 250, 250, 100));
		}
	}
}

void Game::checkPlayerCordinates()
{
	if (p->y >= 260)
	{
		if (p->y <= (1020 - (2.4 * p->x))) enemy2->fire(1);
		else if (p->y <= ((2.4 * p->x) - 500)) enemy2->fire(2);
		else enemy2->fire(0);
	}

}

void Game::drawObjects(sf::RenderWindow& window)
{
	if (!end)
	{
		if (!animation)
		{
			for (int i = 0; i < numberOfEnemies; i++)
			{
				if (!Invaderpause)
				{
					if (bomb[i])
						window.draw(bomb[i]->sprite);
					if (enemy[i])
					{
						window.draw(enemy[i]->sprite);
					}
				}
			}

			if (Invaderpause)
			{
				window.draw(enemy2->bomb->sprite);
				window.draw(enemy2->sprite);
			}

			if (p)
			{
				if (up && right)
				{
					p->spriteR.setPosition(p->x, p->y);
					window.draw(p->spriteR);
				}
				else if (up && left)
				{
					p->spriteL.setPosition(p->x, p->y);
					window.draw(p->spriteL);
				}
				else
				{
					window.draw(p->sprite);
				}

				if (!Invaderpause)
				{
					if (!nextLevelPause)
						window.draw(p->bullet->sprite);
					//if (addOns != nullptr)
					if (addOns)
						window.draw(addOns->sprite);

				}
				left = right = up = down = false;

			}
		}
		if (animation && reverse)
		{
			window.draw(p->sprite);
		}

		if (animation)
		{
			window.draw(obj1);
			window.draw(obj2);
		}

		window.draw(sideBackground);
		window.draw(sideMenu);
		drawFonts(window);
	}

	else
	{
		int count = m.h.Count();

		if (m.h.Search(username))
		{
			if (m.h.getScore(username) < score)
				m.h.Replace(username, score, username);
		}
		else
		{
			if (count < 10)
			{
				m.h.Input(username, score);
				m.h.Sort();
			}
			else if (score > m.h.lowestScore)
			{
				m.h.Replace(username, score, m.h.lowestName);
				m.h.Sort();
			}
		}
		window.draw(sideBackground);
		window.draw(gameOver);
		drawFonts(window);
	}
}

void Game::drawFonts(sf::RenderWindow& window)
{

	string current_lives, firstName, secondName, thirdName, firstScore, secondScore, thirdScore;

	m.h.Sort();

	firstName = m.h.firstHighest;
	secondName = m.h.secondHighest;
	thirdName = m.h.thirdHighest;

	firstScore = to_string(m.h.firstScore);
	secondScore = to_string(m.h.secondScore);
	thirdScore = to_string(m.h.thirdScore);

	if (p) current_lives += to_string(p->lives);

	sf::Text Name, Score, level, lives, fName, sName, tName, fScore, sScore, tScore;

	Name.setFont(font);
	Name.setFillColor(sf::Color::Red);
	Name.setStyle(sf::Text::Bold);
	Name.setCharacterSize(20);

	Score = lives = level = fName = sName = tName = fScore = sScore = tScore = Name;

	Name.setString(username);
	fName.setString(firstName);
	sName.setString(secondName);
	tName.setString(thirdName);
	fScore.setString(firstScore);
	sScore.setString(secondScore);
	tScore.setString(thirdScore);
	Score.setString(to_string(score));
	level.setString(to_string(phase));
	lives.setString(current_lives);

	Name.setPosition(755.f, 100.f);
	level.setPosition(755.f, 130.f);
	Score.setPosition(755.f, 160.f);
	lives.setPosition(755.f, 190.f);
	fName.setPosition(710.f, 260.f);
	sName.setPosition(710.f, 295.f);
	tName.setPosition(710.f, 330.f);
	fScore.setPosition(800.f, 260.f);
	sScore.setPosition(800.f, 295.f);
	tScore.setPosition(800.f, 330.f);


	if (!end)
	{
		window.draw(Score);
		window.draw(Name);
		window.draw(fName);
		window.draw(sName);
		window.draw(tName);
		window.draw(fScore);
		window.draw(sScore);
		window.draw(tScore);
		window.draw(level);
		window.draw(lives);
	}

	if (end)
	{
		Score.setCharacterSize(100);
		Score.setString(to_string(score));
		Score.setPosition(420.f, 320.f);
		window.draw(Score);
	}
}

void Game::initializeVariables()
{
	p = new Player;
	username = "";
	numberOfEnemies = 20;
	enemy2 = NULL;
	bomb = new Bomb * [numberOfEnemies];
	enemy = new Enemy * [numberOfEnemies];
	for (int i = 0; i < 20; i++)
	{
		enemy[i] = NULL;
		bomb[i] = NULL;
	}
	addOns = NULL;

	obj2X = 547;
	obj1X = 0;

	animation = reverse = fireStart = right = left = up = down = nextLevel = end = Invaderpause = nextLevelPause = powerupStart = false;
	powerupTimer = nextLevelTimer = timer = fireTimer = level = phase = score = 0;

	animationStart = pause = true;
}

void Game::writeGame()
{
	fstream MyFile("storedGame.txt", MyFile.out);

	MyFile << username << endl;
	MyFile << level << endl;
	MyFile << score << endl;
	MyFile << p->lives << endl;
	MyFile << p->x << endl;
	MyFile << p->y << endl;

	for (int i = 0; i < numberOfEnemies; i++)
	{
		if (enemy[i])
			MyFile << 1 << endl;
		else
			MyFile << 0 << endl;
	}

	MyFile.close();
}

void Game::readGame()
{
	string myText;
	ifstream MyReadFile("storedGame.txt");

	int count = 0;

	bool arr[20];

	while (getline(MyReadFile, myText))
	{
		count++;

		if (count == 1) username = myText;
		else if (count == 2) level = stoi(myText);
		else if (count == 3) score = stoi(myText);
		else if (count == 4) p->lives = stoi(myText);
		else if (count == 5) p->x = stoi(myText);
		else if (count == 6) p->y = stoi(myText);

		if (count > 6)
			arr[count - 7] = stoi(myText);
	}
	p->sprite.setPosition(p->x, p->y);
	level--;

	chooseLevel();
	animationStart = false;

	for (int i = 0; i < numberOfEnemies; i++)
	{
		if (!(arr[i]))
		{
			delete bomb[i];
			bomb[i] = NULL;
			delete enemy[i];
			enemy[i] = NULL;
		}
	}

	m.username = username;
	MyReadFile.close();
}
#endif
