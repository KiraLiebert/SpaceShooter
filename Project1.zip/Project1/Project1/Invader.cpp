#ifndef INVADER_H
#define INVADER_H

#include "Invader.h"

Invader::Invader()
{
	type = "invader";
	movement = 0;
}

#endif
