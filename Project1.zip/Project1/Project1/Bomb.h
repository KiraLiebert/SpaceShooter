#pragma once
#include <SFML/Graphics.hpp>
#include<string.h>
using namespace std;
using namespace sf;

class Bomb
{
public:
	Texture tex;
	Sprite sprite;
	float x,y;
	bool timed = false;
	bool bombDrop = false;
	string type;
	float xx,yy;
	int r;
	
	bool p = false;
	
public:
	
	Bomb(float, float, std::string);
	void fire(float time);
};
